#ifndef TYPES_HPP
#define TYPES_HPP

#define DATABASE_FILE "test.db"

enum Drying {
    AIR_DRIED,
    KILN_DRIED,
    AIR_AND_KILN_DRIED,
    WET,
};

#endif // TYPES_HPP