#include <string>
#include <iostream>
#include <iomanip>

#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QDockWidget>

#include "project_editor.hpp"
#include "logs.hpp"
#include "types.hpp"
#include "firewood.hpp"

#include "mainwindow.hpp"
#include "ui_mainwindow.h"
#include "inventory.hpp"
#include "cutlist.hpp"
#include "sales.hpp"

#define GROUPED_LOGS_QUERY "SELECT * from logs_view_grouped"
#define LOGS_QUERY "SELECT * FROM logs_view"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    inventoryPage(new InventoryPage()),
    cutlistPage(new CutlistPage()),
    salesPage(new SalesPage()),
    inventoryDock(nullptr)
{
    ui->setupUi(this);

    // Add the corresponding QActions to the menu to show our UI "pages".
    QMenu *menu = menuBar()->addMenu("WoodWorks");
    QAction *inventoryAction = new QAction("Inventory", this);
    QAction *cutlistAction = new QAction("Cutlist", this);
    QAction *salesAction = new QAction("Sales", this);

    menu->addAction(inventoryAction);
    menu->addAction(cutlistAction);
    menu->addAction(salesAction);

    // Establish database connection.
    // Yeah this opens another connection, but it's read-only
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(DATABASE_FILE);
    if (!db.open()) {
        qDebug() << "Database error:" << db.lastError().text();
        return; // Early return if the connection fails.
    }

    auto *groupedModel = new QSqlQueryModel(this);
    auto *logsModel = new QSqlQueryModel(this);
    QString queryStr = GROUPED_LOGS_QUERY;
    QString logsQueryStr = LOGS_QUERY;
    groupedModel->setQuery(queryStr, db);
    logsModel->setQuery(logsQueryStr, db);

    // Check for query errors.
    if (groupedModel->lastError().isValid()) {
        qDebug() << "Query error:" << groupedModel->lastError().text();
    }
    if (logsModel->lastError().isValid()) {
        qDebug() << "Query error:" << logsModel->lastError().text();
    }

    // Set the model to the table view.
    ui->groupedLogsTableView->setModel(groupedModel);
    ui->individualLogTableView->setModel(logsModel);
    refreshModel();

    // Resize the columns to fit the contents.
    ui->groupedLogsTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->individualLogTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    // Connect the add button to the add log slot.
    // Note: With a query model displaying aggregated data, editing is not supported.
    connect(ui->enterLogButton, &QPushButton::clicked, this, &MainWindow::onEnterLogButtonClicked);
    connect(ui->scrapLogButton, &QPushButton::clicked, this, &MainWindow::onScrapLogButtonClicked);
    connect(ui->makeFirewoodButton, &QPushButton::clicked, this, &MainWindow::onFirewoodButtonClicked);
    connect(ui->projectsEditorAction, &QAction::triggered, this, &MainWindow::onProjectEditActionTriggered);

    // Adding the additional UI pages for the various aspects of the app's store front and inventory management system here, for now.
    connect(inventoryAction, &QAction::triggered, this, &MainWindow::showInventoryPage);
    connect(cutlistAction, &QAction::triggered, this, &MainWindow::showCutlistPage);
    connect(salesAction, &QAction::triggered, this, &MainWindow::showSalesPage);
}

void MainWindow::refreshModel()
{
    // Get the current model from the table view.
    auto *groupedModel = qobject_cast<QSqlQueryModel*>(ui->groupedLogsTableView->model());
    if (!groupedModel)
        return;
    auto *logsModel = qobject_cast<QSqlQueryModel*>(ui->individualLogTableView->model());

    // Define the query string (could also be a member variable)
    QString queryStr = GROUPED_LOGS_QUERY;
    QString logsQueryStr = LOGS_QUERY;

    // Re-run the query.
    groupedModel->setQuery(queryStr, QSqlDatabase::database());
    logsModel->setQuery(logsQueryStr, QSqlDatabase::database());

    // Optional: Check for errors.
    if (groupedModel->lastError().isValid()) {
        qDebug() << "Query error:" << groupedModel->lastError().text();
    }
    if (logsModel->lastError().isValid()) {
        qDebug() << "Query error:" << logsModel->lastError().text();
    }
}

void MainWindow::onEnterLogButtonClicked() {
    // Get values from the UI widgets
    QString species = ui->speciesText->text();
    int lenFt = ui->lenFt->value();
    int lenIn = ui->lenIn->value();
    int diamIn = ui->diamIn->value();
    double costVal = ui->cost->value();
    int quality = ui->quality->value();
    std::string location = ui->locationEntry->text().toStdString();

    int lenQuarters = (lenFt * 12 + lenIn) * 4;
    int diamQuarters = diamIn * 4;

    int costCents = costVal * 100;
    int costQuarters = costCents / lenQuarters;

    // Create a log object, insert it into the database
    Log log(0, species.toStdString(), lenQuarters, diamQuarters, costQuarters, quality, location);
    log.insert();

    // Refresh the model
    refreshModel();
}

void MainWindow::onScrapLogButtonClicked() {
    // Get the selected log ID
    QModelIndex index = ui->individualLogTableView->currentIndex();
    std::optional<Log> log = Log::get_by_id(index.sibling(index.row(), 0).data().toInt());

    // If the log is not found, return, after displaying an error message
    if (!log) {
        QMessageBox::critical(this, "Error", "Log not found");
        return;
    }

    // Scrap the log
    log->scrap();

    // Update the model
    refreshModel();
}

void MainWindow::onFirewoodButtonClicked() {
    // Get the selected log ID, and get log object
    std::optional<Log> opt = Log::get_by_id(ui->individualLogTableView->currentIndex().siblingAtColumn(0).data().toInt());

    if (!opt) {
        QMessageBox::critical(this, "Error", "Log not found");
        return;
    }

    // Confirm that they want to turn the log into firewood
    QMessageBox::StandardButton reply = QMessageBox::question(this, "Confirm", "Are you sure you want to turn this entire log into firewood?", QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::No) {
        return;
    }

    std::cout << "Turning log into firewood" << std::endl;

    // We're going to convert the entire usable length of the log into firewood
    Log log = opt.value();
    int usableLength = log.getAvailableLength();

    // Manufacture the log into firewood
    auto firewood = Firewood::make_from_log(log, usableLength);

    refreshModel();
}

void MainWindow::onProjectEditActionTriggered() {
   ProjectEditorWindow *projectEditor = new ProjectEditorWindow(this);
   projectEditor->show();
}

MainWindow::~MainWindow() 
{
    delete ui;
    // TODO: Remove these after testing. This is actually double deleting because
    // of the QT parenting system, these are effectively shared pointers in the main window
    // and will be cleaned up by scope resolution.
    //delete inventoryPage;
    //delete cutlistPage;
    //delete salesPage;
}

void MainWindow::showInventoryPage() 
{
    if (!inventoryDock) {
        inventoryDock = new QDockWidget("Inventory", this);

        inventoryDock->setFeatures(QDockWidget::DockWidgetClosable |
                                   QDockWidget::DockWidgetMovable |
                                   QDockWidget::DockWidgetFloatable);

        inventoryDock->setAllowedAreas(Qt::AllDockWidgetAreas);
        inventoryDock->setWidget(inventoryPage);

        addDockWidget(Qt::RightDockWidgetArea, inventoryDock);

        // Enable it to float after adding it, so the flags apply properly.
        // Otherwise window's behavior will be buggy!
        inventoryDock->setFloating(true);
    }

    inventoryDock->show();
    inventoryDock->raise();
}


void MainWindow::showCutlistPage() 
{
    cutlistPage->show();
}

void MainWindow::showSalesPage() 
{
    salesPage->show();
}
